#!/usr/bin/env bash
echo tar xzvf squeeze-alice.tar.gz -C /opt/
sudo tar xzvf squeeze-alice.tar.gz -C /opt/
sudo ls /opt/
sudo ls /opt/squeeze-alice/
$SHELL
