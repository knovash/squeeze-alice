#!/usr/bin/env bash
rm -r log
rm -r squeeze-alice-pak
rm -r target
rm *.json
rm *.gz
