#!/usr/bin/env bash
cd target
java -jar squeeze-alice*.jar localhost
$SHELL
