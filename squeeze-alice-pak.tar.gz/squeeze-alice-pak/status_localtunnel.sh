#!/usr/bin/env bash
sudo service squeeze-tunnel status
$SHELL

