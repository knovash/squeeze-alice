#!/usr/bin/env bash
rm -r target
mvn package
#java -jar squeeze-alice.jar
$SHELL
