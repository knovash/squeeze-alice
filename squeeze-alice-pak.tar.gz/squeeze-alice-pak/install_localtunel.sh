#!/usr/bin/env bash
echo skip install npm and localtunnel
#sudo apt install npm
#sudo npm install -g localtunnel
$SHELL
