#!/usr/bin/env bash
echo copy squeeze-alice.service to /lib/systemd/system/
echo enable squeeze-alice.service
sudo cp squeeze-alice.service /lib/systemd/system/
sudo systemctl enable squeeze-alice.service
sudo systemctl daemon-reload
sudo systemctl start squeeze-alice.service
sudo service squeeze-alice status
$SHELL
