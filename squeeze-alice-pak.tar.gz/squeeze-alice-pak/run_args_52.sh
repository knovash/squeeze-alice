#!/usr/bin/env bash
cd target
java -jar squeeze-alice*.jar 192.168.1.52
$SHELL
