#!/usr/bin/env bash
echo copy squeeze-tunnel.service to /lib/systemd/system/
echo enable squeeze-tunnel.service
sudo cp squeeze-tunnel.service /lib/systemd/system/
sudo systemctl enable squeeze-tunnel.service
sudo systemctl daemon-reload
sudo systemctl start squeeze-tunnel.service
sudo service squeeze-tunnel status
$SHELL
